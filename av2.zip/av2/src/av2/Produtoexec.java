package av2;

import java.util.ArrayList;
import java.util.Scanner;

public class Produtoexec {

    public Produtoexec() {
    }
    ProdutoDAO proddao = new ProdutoDAO();
    PadariaDAO padadao = new PadariaDAO();

    public void insert() {
        Scanner leia = new Scanner(System.in);
        System.out.print("Digite o nome:");
        String nome = leia.nextLine();
        System.out.println("Digite a descricao: ");
        String descricao = leia.nextLine();
        System.out.println("Digite o valor: ");
        double valor = Double.parseDouble(leia.nextLine());
        padadao.listSelect();
        System.out.print("Digite o Id da Padaria - ");
        int id_padaria = Integer.parseInt(leia.nextLine());

        Produto p = new Produto(nome, descricao, valor, id_padaria);

        proddao.insert(p);

    }

    public void delete() {
        Scanner leia = new Scanner(System.in);

        System.out.print("Digite o ID:");
        int id = Integer.parseInt(leia.nextLine());

        Produto p = proddao.getProduto(id);

        if (p != null) {

            proddao.delete(p);
        } else {
            System.out.println("Não existe!");
        }
    }

    public void update() {
        Scanner leia = new Scanner(System.in);
        System.out.println("Digite o ID: ");
        int id = Integer.parseInt(leia.nextLine());
        System.out.print("Digite o nome:");
        String nome = leia.nextLine();
        System.out.println("Digite a descricao: ");
        String descricao = leia.nextLine();
        System.out.println("Digite o valor desse produto: ");
        double valor = Double.parseDouble(leia.nextLine());
        System.out.println("Digite o id_padaria: ");
        padadao.listSelect();
        System.out.print("ID: ");
        int id_padaria = Integer.parseInt(leia.nextLine());
        Produto f = proddao.getProduto(id);
        if (f != null) {
            f.setNome(nome);
            f.setDescricao(descricao);
            f.setValor(valor);
            f.setId_padaria(id_padaria);
            proddao.update(f);
        } else {
            System.out.println("Não existe!");
        }

    }

    public void print() {
        ArrayList<Produto> lista = proddao.getProdutos();
        System.out.println("\tid \tNome \tdescricao \tvalor \tpadaria");
        for (Produto p : lista) {
            Padaria pa = padadao.getPadaria(p.getId_padaria());
             System.out.println("\t" + p.getId() + " \t" + p.getNome() + " \t" + p.getDescricao() + "\t" + p.getValor() + " \t" + pa.getNome());
        
        }
    }
    
    public void printavg(){
          System.out.println("Média = " + proddao.getAVG());
        
    }
    
    public void exec() {
        Scanner leia = new Scanner(System.in);

        int op = 1;
     
        while (op != 0) {
            System.out.println("-|-|-|-|-|-|-|-|- Produto -|-|-|-|-|-|-|-|-|-|-|-|-\n");
            System.out.println("1--Cadastrar produtos\n");
            System.out.println("2--Remover produto pelo id\n");
            System.out.println("3--Imprimir os produtos\n");
            System.out.println("4--Alterar os dados pelo id\n");
            System.out.println("5--Média dos valores de todos os produtos\n");
            System.out.println("0--Sair\n");
               System.out.print("\"Opção: \n");

            op = Integer.parseInt(leia.nextLine());
            
            switch(op){
                case 0: 
                    System.out.println("Finalizando...........\n");
                    break;
                case 1:
                    this.insert();
                    break;
                case 2:
                    this.delete();
                    break;
                case 3:
                    this.print();
                    break;
                case 4:
                    this.update();
                    break;
                case 5:
                    this.printavg();
                    break;
                default:
                    System.out.println("Opção menor que 0 e maior 5!!Tenta outra\n");
                    break;
            }
        }
        }
        
    }
        
        
        

