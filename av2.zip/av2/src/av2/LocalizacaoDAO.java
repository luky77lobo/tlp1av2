package av2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class LocalizacaoDAO {

    private Connection getConnection() {
        String url = "jdbc:postgresql://localhost:5432/tlp1av2?user=postgres&password=1213";
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    public void insert(Localizacao l) {
        Connection conn = getConnection();
    String sql = "INSERT INTO localizacao(nome, valor_aluguel) VALUES (?, ?);";

        try {
            PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setString(1, l.getNome());
    
            sentenca.setDouble(2, l.getValor_aluguel());
            

            sentenca.execute();

            sentenca.close();
            conn.close();
        } catch (SQLException sq) {
            sq.printStackTrace();
        }
    }

    public void delete(Localizacao l) {
        Connection conn = getConnection();
        String sql = "DELETE from localizacao where id = ?";

        try {
            PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setInt(1, l.getId());

            sentenca.execute();

            sentenca.close();
            conn.close();
        } catch (SQLException sq) {
            sq.printStackTrace();
        }
    }

    public void deletenome(Localizacao l) {
        Connection conn = getConnection();
        String sql = "DELETE from localizacao where nome = ?";

        try {
           PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setString(1, l.getNome());

            sentenca.execute();

            sentenca.close();
            conn.close();
        } catch (SQLException sq) {
            sq.printStackTrace();
        }
    }

    public void update(Localizacao l) {
        Connection conn = getConnection();
        String sql = "Update localizacao set nome = ?, valor_aluguel = ? where id = ?;";
        try {
            PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setString(1, l.getNome());
         
            sentenca.setDouble(2, l.getValor_aluguel());
            sentenca.setInt(3, l.getId());
            sentenca.execute();

            sentenca.close();
            conn.close();
        } catch (SQLException S) {
            S.printStackTrace();
        }
    }

    public void list() {
        Connection conn = getConnection();

        try {
            
          Statement sentenca = conn.createStatement();
String sql = "Select * from localizacao l ORDER BY l.id";
            ResultSet resultado = sentenca.executeQuery(sql);
            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nome = resultado.getString("nome");
              
                double valor_aluguel = resultado.getDouble("valor_aluguel");
            
                
                Localizacao l = new Localizacao(id, nome, valor_aluguel);
                System.out.println(l);
            }
            sentenca.close();
            conn.close();

        } catch (SQLException s) {
            s.printStackTrace();
        }

    }
   public int getQuantidade(){
       Connection conn = getConnection();

        try {
            Statement sentenca = conn.createStatement();
            String sql = "SELECT count(*) as qtd FROM localizacao l;";
            ResultSet resultado = sentenca.executeQuery(sql);
            if (resultado.next()) {
                return resultado.getInt("qtd");
            }
            sentenca.close();
            conn.close();
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return 0;
       
   }
     public Localizacao getLocalizacao(int id) {
        Connection conn = getConnection();
        String sql = "select * from localizacao l where id = ?;";

        try {
            PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setInt(1, id);

            ResultSet resultado = sentenca.executeQuery();

            if (resultado.next()) {

                id = resultado.getInt("id");
             
                String nome = resultado.getString("nome");
              
                double valor_aluguel = resultado.getDouble("valor_aluguel");
            
                
                Localizacao l = new Localizacao(id, nome, valor_aluguel);

                return l;

            }

            sentenca.close();
            conn.close();

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return null;
    }

    public ArrayList<Localizacao> getLocalizacoes() {
        ArrayList<Localizacao> lista = new ArrayList<Localizacao>();

        Connection conn = getConnection();
        try {
            Statement sentenca = conn.createStatement();
            String sql = "SELECT * FROM localizacao l ORDER BY l.id";
            ResultSet resultado = sentenca.executeQuery(sql);
            while (resultado.next()) {
               int id = resultado.getInt("id");
                String nome = resultado.getString("nome");
              
                double valor_aluguel = resultado.getDouble("valor");
        
                
           Localizacao l = new Localizacao(id, nome, valor_aluguel);

                lista.add(l);
            }
            sentenca.close();
            conn.close();
        } catch (SQLException e) {

            e.printStackTrace();
        }

        return lista;
    }

    public void listSelect() {
        Connection conn = getConnection();
        try {
            Statement sentenca = conn.createStatement();
            String sql = "SELECT * FROM localizacao l ORDER BY l.id";
            ResultSet resultado = sentenca.executeQuery(sql);
            System.out.print("(");
            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nome = resultado.getString("nome");
                double va = resultado.getDouble("valor_aluguel");

                System.out.print(id + "-" + nome + " | " + "-" + va);

            }
            System.out.println(")");

            sentenca.close();
            conn.close();
        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
    
}
