package av2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class PadariaDAO {

    private Connection getConnection() {
        String url = "jdbc:postgresql://localhost:5432/tlp1av2?user=postgres&password=1213";
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    public void insert(Padaria p) {
        Connection conn = getConnection();
        String sql = "INSERT INTO padaria(nome, avaliacao, id_localizacao) VALUES (?,?,?);";

        try {
            PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setString(1, p.getNome());
            sentenca.setString(2, p.getAvaliacao());
            sentenca.setInt(3, p.getId_localizacao());

            sentenca.execute();

            sentenca.close();
            conn.close();
        } catch (SQLException sq) {
            sq.printStackTrace();
        }
    }

    public void deleteid(Padaria p) {
        Connection conn = getConnection();
        String sql = "DELETE from padaria where id = ?";

        try {
            PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setInt(1, p.getId());

            sentenca.execute();

            sentenca.close();
            conn.close();
        } catch (SQLException sq) {
            sq.printStackTrace();
        }
    }

    public void deletenome(Padaria p) {
        Connection conn = getConnection();
        String sql = "DELETE from padaria where nome = ?";

        try {
            PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setString(1, p.getNome());

            sentenca.execute();

            sentenca.close();
            conn.close();
        } catch (SQLException sq) {
            sq.printStackTrace();
        }
    }

    public void update(Padaria p) {
        Connection conn = getConnection();
        String sql = "Update padaria set nome = ?, avaliacao = ?, id_localizacao = ? where id = ?;";
        try {
            PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setString(1, p.getNome());
            sentenca.setString(2, p.getAvaliacao());
            sentenca.setInt(3, p.getId_localizacao());
            sentenca.setInt(4, p.getId());
            sentenca.execute();

            sentenca.close();
            conn.close();
        } catch (SQLException S) {
            S.printStackTrace();
        }
    }

    public void list() {
        Connection conn = getConnection();

        try {
            String sql = "Select * from padaria p ORDER BY p.id";
            PreparedStatement sentenca = conn.prepareStatement(sql);

            ResultSet resultado = sentenca.executeQuery(sql);
            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nome = resultado.getString("nome");
                String avaliacao = resultado.getString("avaliacao");
                int id_localizacao = resultado.getInt("id_localizacao");
                
                Padaria p = new Padaria(id,nome, avaliacao, id_localizacao);
                System.out.println(p);
            }
            sentenca.close();
            conn.close();

        } catch (SQLException s) {
            s.printStackTrace();
        }

    }
   public int getQuantidade(){
       Connection conn = getConnection();

        try {
            Statement sentenca = conn.createStatement();
            String sql = "SELECT count(*) as qtd FROM padaria p;";
            ResultSet resultado = sentenca.executeQuery(sql);
            if (resultado.next()) {
                return resultado.getInt("qtd");
            }
            sentenca.close();
            conn.close();
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return 0;
       
   }
     public Padaria getPadaria(int id) {
        Connection conn = getConnection();
        String sql = "select * from padaria p where id = ?;";

        try {
            PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setInt(1, id);

            ResultSet resultado = sentenca.executeQuery();

            if (resultado.next()) {

               id = resultado.getInt("id");
                String nome = resultado.getString("nome");
                String avaliacao = resultado.getString("avaliacao");
                int id_localizacao = resultado.getInt("id_localizacao");
                
                Padaria p = new Padaria(id,nome, avaliacao, id_localizacao);

                return p;

            }

            sentenca.close();
            conn.close();

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return null;
    }

    public ArrayList<Padaria> getPadarias() {
        ArrayList<Padaria> lista = new ArrayList<Padaria>();

        Connection conn = getConnection();
        try {
            Statement sentenca = conn.createStatement();
            String sql = "SELECT * FROM padaria p ORDER BY p.id";
            ResultSet resultado = sentenca.executeQuery(sql);
            while (resultado.next()) {
               int id = resultado.getInt("id");
                String nome = resultado.getString("nome");
                String avaliacao = resultado.getString("avaliacao");
                int id_localizacao = resultado.getInt("id_localizacao");
                
                Padaria p = new Padaria(id,nome, avaliacao, id_localizacao);

                lista.add(p);
            }
            sentenca.close();
            conn.close();
        } catch (SQLException e) {

            e.printStackTrace();
        }

        return lista;
    }

    public void listSelect() {
        Connection conn = getConnection();
        try {
            Statement sentenca = conn.createStatement();
            String sql = "SELECT * FROM padaria p ORDER BY p.id";
            ResultSet resultado = sentenca.executeQuery(sql);
            System.out.print("(");
            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nome = resultado.getString("nome");

                System.out.print(id + "-" + nome + " | ");

            }
            System.out.println(")");

            sentenca.close();
            conn.close();
        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
    
}
