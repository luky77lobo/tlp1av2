
package av2;

import java.util.ArrayList;
import java.util.Scanner;

public class Padariaexec {

    public Padariaexec() {
    }
    
    
    LocalizacaoDAO locdao = new LocalizacaoDAO();
    PadariaDAO padadao = new PadariaDAO();
    
    public void insert(){
         Scanner leia = new Scanner(System.in);
        System.out.print("Digite o nome:");
        String nome = leia.nextLine();
        System.out.println("Digite a avaliaçao: ");
        String avaliacao = leia.nextLine();

        locdao.listSelect();
        System.out.print("Digite o Id da Localizacao - ");
        int id_localizacao = Integer.parseInt(leia.nextLine());

        Padaria pa = new Padaria(nome, avaliacao, id_localizacao);

        padadao.insert(pa);
    }
    
    public void delete(){
         Scanner leia = new Scanner(System.in);

        System.out.print("Digite o ID:");
        int id = Integer.parseInt(leia.nextLine());
        
        Padaria p = padadao.getPadaria(id);
        if(p != null){
            padadao.deleteid(p);
        }else{
            System.out.println("Não existe");
        }
        
    }
    
    public void update(){
        Scanner leia = new Scanner(System.in);
        System.out.println("Digite o ID: ");
        int id = Integer.parseInt(leia.nextLine());
        System.out.print("Digite o nome:");
        String nome = leia.nextLine();
        System.out.println("Digite a avaliaçao: ");
        String avaliacao = leia.nextLine();
        System.out.print("Digite o Id da Localizacao - ");
        locdao.listSelect();
        System.out.println("ID: ");
        int id_localizacao = Integer.parseInt(leia.nextLine());
        Padaria p = new Padaria(id, nome, avaliacao, id_localizacao);
         if (p != null) {
            p.setNome(nome);
            p.setAvaliacao(avaliacao);
            
            p.setId_localizacao(id_localizacao);
            padadao.update(p);
        } else {
            System.out.println("Não existe!");
        }
        
    }
    
    public void print(){
        ArrayList<Padaria> lista = padadao.getPadarias();
        System.out.println("\t Nome \t Avaliacao \t Localizacao ");
         for (Padaria pa : lista) {
             Localizacao l = locdao.getLocalizacao(pa.getId_localizacao()); //chave estrangeira
             System.out.println(/* "\t" + pa.getId() + */ " \t" + pa.getNome() + " \t" + pa.getAvaliacao()  + " \t" + l.getNome());
         }
         }
    
    public void qtd(){
        System.out.println("Quantidade = " + padadao.getQuantidade());
    }
    
    public void exec(){
        Scanner leia = new Scanner(System.in);

        int op = 1;
     
        while (op != 0) {
            System.out.println("==================-|-|-|-|-Padaria-|-|-|-|==============\n");
            System.out.println("1--Cadastrar padaria");
            System.out.println("2--Remover a padaria pelo id");
            System.out.println("3--Imprimir as padarias");
            System.out.println("4--Alterar os dados pelo id");
            System.out.println("5--Quantidade de padarias");
            System.out.println("0--Sair");
               System.out.print("\"Opção: \n");

            op = Integer.parseInt(leia.nextLine());
            
            switch(op){
                case 0:
                    System.out.println("до побачення(tchau em ucraniano).............\n");
                    break;
                    
                case 1:
                    this.insert();
                    
                    break;
                    
                case 2:
                    this.delete();
                    break;
                case 3:
                    this.print();
                    break;
                    
                case 4:
                    this.update();
                    break;
                    
                case 5:
                    this.qtd();
                    break;
                
                default:
                    System.out.println("Inválido\n");
                    break;
                    
            }
        
        
        
        
    }
    
}
    
}
