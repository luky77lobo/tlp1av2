
package av2;


public class Produto {

    
    private int id;
    private String nome;
    private String descricao;
    private double valor;
    private int id_padaria;

    public Produto(String nome, String descricao, double valor, int id_padaria) {
        this.nome = nome;
        this.descricao = descricao;
        this.valor = valor;
        this.id_padaria = id_padaria;
    }
    
    public Produto(int id, String nome, String descricao, double valor, int id_padaria) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.valor = valor;
        this.id_padaria = id_padaria;
    }
    
    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }


    @Override
    public String toString() {
        return "Produto{" + "id=" + id + ", nome=" + nome + ", descricao=" + descricao + ", id_padaria=" + id_padaria + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Produto other = (Produto) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getId_padaria() {
        return id_padaria;
    }

    public void setId_padaria(int id_padaria) {
        this.id_padaria = id_padaria;
    }

    public Produto(int id, String nome, String descricao, int id_padaria) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.id_padaria = id_padaria;
    }

    public Produto(String nome, String descricao, int id_padaria) {
        this.nome = nome;
        this.descricao = descricao;
        this.id_padaria = id_padaria;
    }
    
}
