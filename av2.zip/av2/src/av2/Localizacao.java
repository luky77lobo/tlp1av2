
package av2;


public class Localizacao {
 private int id;
 private String nome;
 private double valor_aluguel;

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 47 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Localizacao other = (Localizacao) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Localizacao{" + "id --> " + id + ", nome --> " + nome + ", valor_aluguel=" + valor_aluguel + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getValor_aluguel() {
        return valor_aluguel;
    }

    public void setValor_aluguel(double valor_aluguel) {
        this.valor_aluguel = valor_aluguel;
    }

    public Localizacao(int id, String nome, double valor_aluguel) {
        this.id = id;
        this.nome = nome;
        this.valor_aluguel = valor_aluguel;
    }

    public Localizacao(String nome, double valor_aluguel) {
        this.nome = nome;
        this.valor_aluguel = valor_aluguel;
    }
 
}
