package av2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ProdutoDAO {

    private Connection getConnection() {
        String url = "jdbc:postgresql://localhost:5432/tlp1av2?user=postgres&password=1213";
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    public void insert(Produto pr) {
        Connection conn = getConnection();
    String sql = "INSERT INTO produto(nome, descricao, valor, id_padaria) VALUES (?, ?, ?, ?);";

        try {
            PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setString(1, pr.getNome());
            sentenca.setString(2, pr.getDescricao());
            sentenca.setDouble(3, pr.getValor());
            sentenca.setInt(4, pr.getId_padaria());

            sentenca.execute();

            sentenca.close();
            conn.close();
        } catch (SQLException sq) {
            sq.printStackTrace();
        }
    }

    public void delete(Produto pr) {
        Connection conn = getConnection();
        String sql = "delete from produto where id = ?";

        try {
            PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setInt(1, pr.getId());

            sentenca.execute();

            sentenca.close();
            conn.close();
        } catch (SQLException sq) {
            sq.printStackTrace();
        }
    }

    public void deletenome(Produto pr) {
        Connection conn = getConnection();
        String sql = "DELETE from padaria where nome = ?";

        try {
           PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setString(1, pr.getNome());

            sentenca.execute();

            sentenca.close();
            conn.close();
        } catch (SQLException sq) {
            sq.printStackTrace();
        }
    }

    public void update(Produto pr) {
        Connection conn = getConnection();
        String sql = "Update produto set nome = ?, descricao = ?, valor = ?, id_padaria = ? where id = ?;";
        try {
            PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setString(1, pr.getNome());
            sentenca.setString(2, pr.getDescricao());
            sentenca.setDouble(3, pr.getValor());
            sentenca.setInt(4, pr.getId_padaria());
            sentenca.setInt(5, pr.getId());
            sentenca.execute();

            sentenca.close();
            conn.close();
        } catch (SQLException S) {
            S.printStackTrace();
        }
    }

    public void list() {
        Connection conn = getConnection();

        try {
            String sql = "Select * from produto pr ORDER BY pr.id";
            PreparedStatement sentenca = conn.prepareStatement(sql);

            ResultSet resultado = sentenca.executeQuery(sql);
            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nome = resultado.getString("nome");
                String descricao = resultado.getString("descricao");
                double valor = resultado.getDouble("valor");
                int id_padaria = resultado.getInt("id_padaria");
                
                Produto pr = new Produto(id, nome, descricao, valor, id_padaria);
                System.out.println(pr);
            }
            sentenca.close();
            conn.close();

        } catch (SQLException s) {
            s.printStackTrace();
        }

    }
   public int getQuantidade(){
       Connection conn = getConnection();

        try {
            Statement sentenca = conn.createStatement();
            String sql = "SELECT count(*) as qtd FROM produto pr;";
            ResultSet resultado = sentenca.executeQuery(sql);
            if (resultado.next()) {
                return resultado.getInt("qtd");
            }
            sentenca.close();
            conn.close();
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return 0;
       
   }
   
   public double getAVG(){
       Connection conn = getConnection();
       
       try{
          Statement sentenca = conn.createStatement();
            String sql = "Select ROUND(AVG(valor),2) as media FROM produto;";
            ResultSet resultado = sentenca.executeQuery(sql);
            if(resultado.next()){
                return resultado.getDouble("media");
            }
            sentenca.close();
            conn.close();
       }
       catch(SQLException sq){
           sq.printStackTrace();
       }
       
       return 0.00;
   }
     public Produto getProduto(int id) {
        Connection conn = getConnection();
        String sql = "select * from produto pr where id = ?;";

        try {
            PreparedStatement sentenca = conn.prepareStatement(sql);
            sentenca.setInt(1, id);

            ResultSet resultado = sentenca.executeQuery();

            if (resultado.next()) {

                id = resultado.getInt("id");
                String nome = resultado.getString("nome");
                String descricao = resultado.getString("descricao");
                double valor = resultado.getDouble("valor");
                int id_padaria = resultado.getInt("id_padaria");
                
                Produto pr = new Produto(id, nome, descricao, valor, id_padaria);

                return pr;

            }

            sentenca.close();
            conn.close();

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return null;
    }

    public ArrayList<Produto> getProdutos() {
        ArrayList<Produto> lista = new ArrayList<Produto>();

        Connection conn = getConnection();
        try {
            Statement sentenca = conn.createStatement();
            String sql = "SELECT * FROM produto pr ORDER BY pr.id";
            ResultSet resultado = sentenca.executeQuery(sql);
            while (resultado.next()) {
               int id = resultado.getInt("id");
                String nome = resultado.getString("nome");
                String descricao = resultado.getString("descricao");
                double valor = resultado.getDouble("valor");
                int id_padaria = resultado.getInt("id_padaria");
                
                Produto pr = new Produto(id, nome, descricao, valor, id_padaria);

                lista.add(pr);
            }
            sentenca.close();
            conn.close();
        } catch (SQLException e) {

            e.printStackTrace();
        }

        return lista;
    }

    public void listSelect() {
        Connection conn = getConnection();
        try {
            Statement sentenca = conn.createStatement();
            String sql = "SELECT * FROM produto pr ORDER BY pr.id";
            ResultSet resultado = sentenca.executeQuery(sql);
            System.out.print("(");
            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nome = resultado.getString("nome");
                double valor = resultado.getDouble("valor");
                System.out.print(id + "-" + nome + " | " + "-" + valor);

            }
            System.out.println(")");

            sentenca.close();
            conn.close();
        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
    
}
