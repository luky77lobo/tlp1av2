
package av2;

import java.util.Scanner;


public class Localizacaoexec {
    LocalizacaoDAO locdao = new LocalizacaoDAO();

    public Localizacaoexec() {
    }
    public void insert(){
         Scanner leia = new Scanner(System.in);
        System.out.print("Digite o nome onde mora:");
        String nome = leia.nextLine();
        System.out.println("Digite o valor do seu aluguel: ");
        double valor_aluguel = leia.nextDouble(); 
    
        Localizacao l = new Localizacao(nome, valor_aluguel);
        
        locdao.insert(l);
    }
    public void delete(){
         Scanner leia = new Scanner(System.in);

        System.out.print("Digite o ID:");
        int id = Integer.parseInt(leia.nextLine());

        Localizacao l  = locdao.getLocalizacao(id);

        if (l != null) {

            locdao.delete(l);
        } else {
            System.out.println("Não existe!");
        }
    }
    public void print(){
        locdao.list();
    }
    public void qtd(){
        System.out.println("Quantidade = " + locdao.getQuantidade());
    }
    public void update(){
         Scanner leia = new Scanner(System.in);
        System.out.println("Digite o ID: ");
        int id = Integer.parseInt(leia.nextLine());
        System.out.print("Digite o nome:");
        String nome = leia.nextLine();
        System.out.println("Digite o valor para o seu aluguel: ");
        double vaaluguel = Double.parseDouble(leia.nextLine());
        Localizacao l = locdao.getLocalizacao(id);
        if(l != null){
            l.setNome(nome);
            l.setValor_aluguel(vaaluguel);
            locdao.update(l);
        } else {
            System.out.println("Inexistente");
        }
        
    }
    
    public void exec(){
         Scanner leia = new Scanner(System.in);

        int op = 1;
         while (op != 0) {
        System.out.println("-----------------Localizacao--------------\n");
        System.out.println("1 -- Cadastrar localizações\n");
        System.out.println("2 -- Remover localização pelo id\n");
        System.out.println("3 -- Imprimir as localizações\n");
        System.out.println("4 -- Alterar os dados pelo id\n");
        System.out.println("5 -- Quantidade");
          System.out.println("0--Sair\n");
               System.out.print("\"Opção: \n");

            op = Integer.parseInt(leia.nextLine());
          switch(op){
              case 0:
                  System.out.println("Finalizando........");
                  break;
              case 1:
                  this.insert();
                  break;
                 
              case 2:
                   this.delete();
                 
                  break;
                  
              case 3:
                   this.print();
                  break;
               
              case 4:
                  
                  this.update();
                  break;
                  
              case 5:
                  
                  this.qtd();
                  break;
               
              default:
                  System.out.println("Opção inválida\n");
                  break;
              
          }  
        
         }
        
    }
  
   
    
}
