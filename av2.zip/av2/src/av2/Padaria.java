
package av2;


public class Padaria {
    private int id;
    private String nome;
    private String avaliacao;
    
    private int id_localizacao;

    public Padaria(int id, int id_localizacao) {
        this.id = id;
        this.id_localizacao = id_localizacao;
    }

    @Override
    public String toString() {
        return "Padaria{" + "id ---> " + id + ", nome --> " + nome + ", avaliacao --> " + avaliacao + ", id_localizacao --> " + id_localizacao + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Padaria other = (Padaria) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getAvaliacao() {
        return avaliacao;
    }

    public void setAvaliacao(String avaliacao) {
        this.avaliacao = avaliacao;
    }

    public int getId_localizacao() {
        return id_localizacao;
    }

    public void setId_localizacao(int id_localizacao) {
        this.id_localizacao = id_localizacao;
    }

    public Padaria(int id, String nome, String avaliacao, int id_localizacao) {
        this.id = id;
        this.nome = nome;
        this.avaliacao = avaliacao;
        this.id_localizacao = id_localizacao;
    }

    public Padaria(String nome, String avaliacao, int id_localizacao) {
        this.nome = nome;
        this.avaliacao = avaliacao;
        this.id_localizacao = id_localizacao;
    }
    
}
